// eslint-disable-next-line no-undef
module.exports = require("./packages/eslint-config-folk");
