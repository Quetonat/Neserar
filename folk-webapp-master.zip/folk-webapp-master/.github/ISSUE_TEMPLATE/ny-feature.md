---
name: Ny Feature
about: Issue mal for ny funksjonalitet
title: ""
labels: enhancement
assignees: ""
---

**Er funksjonaliteten relatert til et problem? Vennligst utdyp.**
En konkret beskrivelse av hva problemet er.

**Beskriv løsningen du ønsker**
En konkret beskrivelse av løsningen.

**Beskriv eventuelle alternativer du har vurdert**
Konkret beskrivelse av alternativ løsning på problemet.

**Ekstra beskrivelse**
Legg til ekstra informasjon som screenshots eller lignende.
