---
name: Bugfiks
about: Issue mal for bugfiksing
title: ""
labels: bug
assignees: ""
---

**Beskriv feilen**
Konkret beskrivelse av hva feilen er.

**Hvordan reprodusere feil**
F.eks.

1. Gå til '...'
2. Klikk på '....'
3. Skråll ned til '....'
4. Se feil

**Forventet oppførsel**
Konkret beskrivelse av hva man forventer skal skje.

**Ekstra kontekst**
Legg ved skjermbilde eller tilleggsinformasjon.
