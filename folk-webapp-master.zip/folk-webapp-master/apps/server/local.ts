import app from './app'

const port = 3010

app.listen(port)
console.log(`listening on http://localhost:${port}`)
