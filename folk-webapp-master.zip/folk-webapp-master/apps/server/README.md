# Knowit folk backend

Please see the [Wiki](https://github.com/knowit/folk-webapp/wiki/Backend).
