module.exports = {
  extends: ['eslint-config-folk'],
  root: true,
  env: {
    es2021: true,
    node: true,
    commonjs: true,
  },
}
