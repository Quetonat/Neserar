export interface CompetenceFilterResponse {
  category: string
  subCategories: string[]
}
