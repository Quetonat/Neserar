export interface TableRow<TRowData> {
  rowId: string
  rowData: TRowData
}
