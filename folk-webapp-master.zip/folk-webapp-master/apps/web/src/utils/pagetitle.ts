export const pageTitle = (subtitle: string) => {
  document.title = subtitle + ' - Knowit Folk'
}
