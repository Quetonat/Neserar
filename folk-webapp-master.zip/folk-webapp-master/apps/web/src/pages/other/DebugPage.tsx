import React from 'react'
import { pageTitle } from '../../utils/pagetitle'

const Debug = () => {
  pageTitle('Debug')
  return <div>buggin</div>
}

export default Debug
