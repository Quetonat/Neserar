import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Box,
  Paper,
} from '@mui/material'

import { Minimize, Add } from '@mui/icons-material'
import React, { useState } from 'react'
import { EmployeeForCustomerList } from '../../../api/data/customer/customerApiTypes'
import { Link } from 'react-router-dom'
import { OpenInNewIcon } from '../../../assets/Icons'
import { styled } from '@mui/material/styles'
import { EmployeeTableForCustomer } from '../../employee/table/SortableEmployeeTable'

interface CustomerDropdownProps {
  customerName: string
  employees: EmployeeForCustomerList[]
  expand?: boolean
}

const CustomerColumn = styled('div')(() => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
}))

const CustomerAccordion = ({
  customerName,
  employees,
  expand = false,
}: CustomerDropdownProps) => {
  const [expanded, setExpanded] = useState(expand)

  return (
    <Box
      sx={{
        margin: 0,
        display: 'flex',
        flexDirection: 'column',
        height: 'max-content',
        width: '100%',
        flex: '1',
      }}
    >
      <Accordion
        expanded={expanded}
        onChange={() => setExpanded(!expanded)}
        square={true}
      >
        <AccordionSummary expandIcon={expanded ? <Minimize /> : <Add />}>
          <Box
            sx={{
              margin: 0,
              display: 'grid',
              flexDirection: 'row',
              width: '85%',
              gridTemplateColumns: '1fr 1fr',
            }}
          >
            <CustomerColumn>
              {customerName}
              {customerName != 'Uten prosjekt' && (
                <Link to={'/kunder/' + customerName} target="_blank">
                  <OpenInNewIcon />
                </Link>
              )}
            </CustomerColumn>
            <div style={{ marginLeft: 15 }}>
              Antall konsulenter: {employees.length}
            </div>
          </Box>
        </AccordionSummary>
        <AccordionDetails>
          <Paper
            elevation={0}
            style={{
              height: '100%',
              width: '100%',
            }}
            sx={{ backgroundColor: 'background.default' }}
          >
            <EmployeeTableForCustomer data={employees} />
          </Paper>
        </AccordionDetails>
      </Accordion>
    </Box>
  )
}

export default React.memo(CustomerAccordion)
