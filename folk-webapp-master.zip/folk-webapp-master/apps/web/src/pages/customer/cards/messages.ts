export const POSSIBLE_OLD_DATA_WARNING =
  'Dataene er fra første registrering i UBW. Noen av dataene kan være justert i etterkant, og disse justeringene er ikke oppdatert her.'
